import { useState } from 'react';
import './App.css';

const API = 'http://localhost:5000';

const MOODS = ['tired', 'craving', 'sad', 'healthy'];
const BUDGETS = ['low', 'medium', 'high'];
const TYPES = ['veg', 'non-veg'];
const LOCATIONS = ['hostel', 'home', 'outside'];

const acneColor = { low: '#4ade80', medium: '#facc15', high: '#f87171' };
const acneEmoji = { low: '✅', medium: '⚠️', high: '🔴' };
const moodEmoji = { tired: '😴', craving: '🤤', sad: '😢', healthy: '💪' };
const budgetEmoji = { low: '💰', medium: '💳', high: '💎' };

function FoodCard({ food, highlight }) {
  return (
    <div className={`food-card ${highlight ? 'highlight' : ''}`}>
      <div className="card-header">
        <h3 className="food-name">{food.name}</h3>
        <span className="acne-badge" style={{ background: acneColor[food.acneRisk] }}>
          {acneEmoji[food.acneRisk]} Acne: {food.acneRisk}
        </span>
      </div>
      <div className="card-stats">
        <div className="stat"><span className="stat-icon">🔥</span><span>{food.calories} cal</span></div>
        <div className="stat"><span className="stat-icon">₹</span><span>{food.price}</span></div>
        <div className="stat"><span className="stat-icon">{food.type === 'veg' ? '🥗' : '🍗'}</span><span>{food.type}</span></div>
      </div>
      <div className="tags">
        {food.tags.map(t => <span key={t} className="tag">{t}</span>)}
      </div>
      {food.reason && <p className="reason">💡 {food.reason}</p>}
    </div>
  );
}

export default function App() {
  const [mood, setMood] = useState('');
  const [budget, setBudget] = useState('');
  const [type, setType] = useState('');
  const [location, setLocation] = useState('');
  const [avoidAcne, setAvoidAcne] = useState(false);
  const [results, setResults] = useState([]);
  const [randomFood, setRandomFood] = useState(null);
  const [messInput, setMessInput] = useState('');
  const [messResult, setMessResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [randomLoading, setRandomLoading] = useState(false);
  const [messLoading, setMessLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('suggest');

  const handleSuggest = async () => {
    setLoading(true);
    setResults([]);
    try {
      const res = await fetch(`${API}/recommend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mood, budget, type, location, avoidAcne })
      });
      const data = await res.json();
      setResults(data);
    } catch (e) {
      alert('Could not connect to backend. Make sure the server is running on port 5000.');
    }
    setLoading(false);
  };

  const handleRandom = async () => {
    setRandomLoading(true);
    setRandomFood(null);
    try {
      const res = await fetch(`${API}/random`);
      const data = await res.json();
      setRandomFood(data);
    } catch (e) {
      alert('Could not connect to backend.');
    }
    setRandomLoading(false);
  };

  const handleOptimize = async () => {
    if (!messInput.trim()) return;
    setMessLoading(true);
    setMessResult(null);
    const items = messInput.split(',').map(s => s.trim()).filter(Boolean);
    try {
      const res = await fetch(`${API}/optimize`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items })
      });
      const data = await res.json();
      setMessResult(data);
    } catch (e) {
      alert('Could not connect to backend.');
    }
    setMessLoading(false);
  };

  return (
    <div className="app">
      <div className="noise-overlay" />

      <header className="app-header">
        <div className="header-blob" />
        <div className="header-content">
          <div className="logo-mark">🍽️</div>
          <h1 className="app-title">What Should<br /><span>I Eat?</span></h1>
          <p className="app-subtitle">Smart food decisions, personalized for you</p>
        </div>
      </header>

      <main className="main-content">
        <div className="tab-bar">
          <button className={`tab-btn ${activeTab === 'suggest' ? 'active' : ''}`} onClick={() => setActiveTab('suggest')}>
            🎯 Smart Suggest
          </button>
          <button className={`tab-btn ${activeTab === 'random' ? 'active' : ''}`} onClick={() => setActiveTab('random')}>
            🎲 Can't Decide
          </button>
          <button className={`tab-btn ${activeTab === 'mess' ? 'active' : ''}`} onClick={() => setActiveTab('mess')}>
            📋 Mess Optimizer
          </button>
        </div>

        {activeTab === 'suggest' && (
          <div className="panel">
            <div className="panel-intro">
              <h2>Tell me about yourself</h2>
              <p>The more you share, the better I'll suggest</p>
            </div>

            <div className="input-grid">
              <div className="input-group">
                <label>How are you feeling? {mood && moodEmoji[mood]}</label>
                <select value={mood} onChange={e => setMood(e.target.value)}>
                  <option value="">Select mood</option>
                  {MOODS.map(m => <option key={m} value={m}>{moodEmoji[m]} {m.charAt(0).toUpperCase() + m.slice(1)}</option>)}
                </select>
              </div>

              <div className="input-group">
                <label>What's your budget? {budget && budgetEmoji[budget]}</label>
                <select value={budget} onChange={e => setBudget(e.target.value)}>
                  <option value="">Select budget</option>
                  {BUDGETS.map(b => <option key={b} value={b}>{budgetEmoji[b]} {b.charAt(0).toUpperCase() + b.slice(1)}</option>)}
                </select>
              </div>

              <div className="input-group">
                <label>Food preference</label>
                <select value={type} onChange={e => setType(e.target.value)}>
                  <option value="">Select type</option>
                  {TYPES.map(t => <option key={t} value={t}>{t === 'veg' ? '🥗' : '🍗'} {t}</option>)}
                </select>
              </div>

              <div className="input-group">
                <label>Where are you?</label>
                <select value={location} onChange={e => setLocation(e.target.value)}>
                  <option value="">Select location</option>
                  {LOCATIONS.map(l => <option key={l} value={l}>{l === 'hostel' ? '🏠' : l === 'home' ? '🏡' : '🛒'} {l.charAt(0).toUpperCase() + l.slice(1)}</option>)}
                </select>
              </div>
            </div>

            <div className="acne-toggle">
              <label className="toggle-label">
                <div className={`toggle-switch ${avoidAcne ? 'on' : ''}`} onClick={() => setAvoidAcne(!avoidAcne)}>
                  <div className="toggle-thumb" />
                </div>
                <span>
                  <strong>Acne-safe mode</strong>
                  <small>Only show low acne-risk foods</small>
                </span>
              </label>
            </div>

            <button className="cta-btn" onClick={handleSuggest} disabled={loading}>
              {loading ? <span className="spinner" /> : '✨'} {loading ? 'Finding perfect meals...' : 'Suggest My Meals'}
            </button>

            {results.length > 0 && (
              <div className="results-section">
                <div className="results-header">
                  <h2>Here's what I recommend</h2>
                  <span className="results-count">{results.length} options</span>
                </div>
                <div className="cards-grid">
                  {results.map((food, i) => <FoodCard key={food.name} food={food} highlight={i === 0} />)}
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'random' && (
          <div className="panel">
            <div className="panel-intro">
              <h2>Let fate decide 🎲</h2>
              <p>Sometimes the universe knows best</p>
            </div>

            <div className="random-section">
              <div className="dice-container" onClick={handleRandom}>
                <div className={`dice ${randomLoading ? 'rolling' : ''}`}>🎲</div>
                <p>Click to roll!</p>
              </div>

              <button className="cta-btn secondary" onClick={handleRandom} disabled={randomLoading}>
                {randomLoading ? <span className="spinner" /> : '🍀'} {randomLoading ? 'Rolling the dice...' : "I Can't Decide — Surprise Me!"}
              </button>

              {randomFood && (
                <div className="random-result">
                  <div className="random-label">🎉 The universe chose...</div>
                  <FoodCard food={randomFood} highlight={true} />
                  <p className="random-msg">No backsies! The food gods have spoken. 🙏</p>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'mess' && (
          <div className="panel">
            <div className="panel-intro">
              <h2>Mess Menu Optimizer 🍱</h2>
              <p>Paste today's mess menu and I'll find the best combo</p>
            </div>

            <div className="mess-section">
              <div className="input-group full-width">
                <label>Enter mess menu items (comma-separated)</label>
                <input
                  type="text"
                  className="mess-input"
                  placeholder="e.g. Maggi, Dal Tadka + Rice, Curd Rice, Poha, Paneer Butter Masala"
                  value={messInput}
                  onChange={e => setMessInput(e.target.value)}
                />
              </div>
              <p className="hint">Try: Maggi, Dal Tadka + Rice, Curd Rice, Poha, Idli Sambar</p>

              <button className="cta-btn" onClick={handleOptimize} disabled={messLoading || !messInput.trim()}>
                {messLoading ? <span className="spinner" /> : '🔍'} {messLoading ? 'Analyzing menu...' : 'Optimize My Choices'}
              </button>

              {messResult && (
                <div className="mess-results">
                  {messResult.best.length > 0 && (
                    <div className="mess-block good">
                      <h3>✅ Best Choices</h3>
                      {messResult.best.map(item => (
                        <div key={item.name} className="mess-item">
                          <strong>{item.name}</strong>
                          <p>{item.reason}</p>
                        </div>
                      ))}
                    </div>
                  )}
                  {messResult.avoid.length > 0 && (
                    <div className="mess-block bad">
                      <h3>🚫 Items to Avoid</h3>
                      {messResult.avoid.map(item => (
                        <div key={item.name} className="mess-item">
                          <strong>{item.name}</strong>
                          <p>{item.reason}</p>
                        </div>
                      ))}
                    </div>
                  )}
                  {messResult.best.length === 0 && messResult.avoid.length === 0 && (
                    <div className="mess-block neutral">
                      <p>⚠️ None of these items matched our food database. Try items like: Maggi, Dal Tadka + Rice, Curd Rice, Poha, etc.</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      <footer className="app-footer">
        <p>Made with 🍜 for hungry humans · What Should I Eat? v1.0</p>
      </footer>
    </div>
  );
}
