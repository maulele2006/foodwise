const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const foods = [
  { name: "Maggi", mood: ["tired", "craving"], budget: "low", type: "veg", location: ["hostel", "home"], acneRisk: "high", calories: 350, price: 50, tags: ["quick", "comfort", "oily"] },
  { name: "Curd Rice", mood: ["tired", "healthy", "sad"], budget: "low", type: "veg", location: ["home", "hostel"], acneRisk: "low", calories: 250, price: 40, tags: ["light", "cooling", "probiotic"] },
  { name: "Chicken Biryani", mood: ["craving", "happy"], budget: "medium", type: "non-veg", location: ["outside", "home"], acneRisk: "medium", calories: 650, price: 180, tags: ["filling", "festive", "spicy"] },
  { name: "Dal Tadka + Rice", mood: ["tired", "healthy", "sad"], budget: "low", type: "veg", location: ["hostel", "home"], acneRisk: "low", calories: 400, price: 60, tags: ["wholesome", "protein", "comfort"] },
  { name: "Masala Dosa", mood: ["craving", "happy"], budget: "low", type: "veg", location: ["outside", "home"], acneRisk: "low", calories: 300, price: 80, tags: ["crispy", "south-indian", "light"] },
  { name: "Grilled Chicken Salad", mood: ["healthy"], budget: "medium", type: "non-veg", location: ["outside", "home"], acneRisk: "low", calories: 280, price: 200, tags: ["protein", "low-carb", "fresh"] },
  { name: "Paneer Butter Masala", mood: ["craving", "happy", "sad"], budget: "medium", type: "veg", location: ["outside", "home"], acneRisk: "medium", calories: 520, price: 160, tags: ["rich", "comfort", "creamy"] },
  { name: "Boiled Eggs + Toast", mood: ["tired", "healthy"], budget: "low", type: "non-veg", location: ["hostel", "home"], acneRisk: "low", calories: 280, price: 40, tags: ["quick", "protein", "simple"] },
  { name: "Veg Fried Rice", mood: ["craving", "tired"], budget: "low", type: "veg", location: ["hostel", "outside", "home"], acneRisk: "medium", calories: 420, price: 90, tags: ["quick", "filling", "oily"] },
  { name: "Banana + Peanut Butter", mood: ["tired", "healthy"], budget: "low", type: "veg", location: ["hostel", "home"], acneRisk: "low", calories: 200, price: 30, tags: ["snack", "energy", "quick"] },
  { name: "Butter Chicken", mood: ["craving", "sad", "happy"], budget: "high", type: "non-veg", location: ["outside"], acneRisk: "high", calories: 600, price: 280, tags: ["rich", "creamy", "indulgent"] },
  { name: "Oats Upma", mood: ["healthy", "tired"], budget: "low", type: "veg", location: ["hostel", "home"], acneRisk: "low", calories: 220, price: 25, tags: ["healthy", "fiber", "quick"] },
  { name: "Shawarma", mood: ["craving", "happy"], budget: "medium", type: "non-veg", location: ["outside"], acneRisk: "high", calories: 480, price: 120, tags: ["street-food", "filling", "oily"] },
  { name: "Sprouts Salad", mood: ["healthy"], budget: "low", type: "veg", location: ["home", "hostel"], acneRisk: "low", calories: 150, price: 20, tags: ["detox", "protein", "fresh"] },
  { name: "Pizza", mood: ["happy", "craving", "sad"], budget: "high", type: "veg", location: ["outside"], acneRisk: "high", calories: 700, price: 350, tags: ["indulgent", "fun", "oily"] },
  { name: "Idli Sambar", mood: ["tired", "healthy", "sad"], budget: "low", type: "veg", location: ["outside", "home"], acneRisk: "low", calories: 230, price: 60, tags: ["light", "south-indian", "steamed"] },
  { name: "Momos", mood: ["craving", "happy", "sad"], budget: "low", type: "veg", location: ["outside"], acneRisk: "medium", calories: 280, price: 80, tags: ["street-food", "comfort", "steamed"] },
  { name: "Fruit Bowl", mood: ["healthy", "tired"], budget: "medium", type: "veg", location: ["home", "outside"], acneRisk: "low", calories: 180, price: 100, tags: ["fresh", "vitamins", "light"] },
  { name: "Mutton Curry + Roti", mood: ["craving", "happy"], budget: "high", type: "non-veg", location: ["home", "outside"], acneRisk: "medium", calories: 680, price: 300, tags: ["heavy", "festive", "protein"] },
  { name: "Poha", mood: ["tired", "healthy"], budget: "low", type: "veg", location: ["home", "hostel"], acneRisk: "low", calories: 250, price: 30, tags: ["light", "breakfast", "quick"] },
];

// POST /recommend
app.post('/recommend', (req, res) => {
  const { mood, budget, type, location, avoidAcne } = req.body;

  let scored = foods.map(food => {
    let score = 0;
    const reasons = [];

    if (mood && food.mood.includes(mood)) { score += 2; reasons.push(`great for when you're feeling ${mood}`); }
    if (budget && food.budget === budget) { score += 2; reasons.push(`fits your ${budget} budget`); }
    if (type && food.type === type) { score += 2; reasons.push(`matches your ${type} preference`); }
    if (location && food.location.includes(location)) { score += 2; reasons.push(`easily available at ${location}`); }

    return { ...food, score, reason: reasons.length ? `Perfect because it's ${reasons.join(', ')}.` : 'A decent general option.' };
  });

  if (avoidAcne) {
    scored = scored.filter(f => f.acneRisk === 'low');
  }

  scored.sort((a, b) => b.score - a.score);
  const top = scored.slice(0, 5).filter(f => f.score > 0);
  res.json(top.length ? top : scored.slice(0, 3));
});

// GET /random
app.get('/random', (req, res) => {
  const food = foods[Math.floor(Math.random() * foods.length)];
  res.json(food);
});

// POST /optimize
app.post('/optimize', (req, res) => {
  const { items } = req.body;
  if (!items || !items.length) return res.json({ best: [], avoid: [] });

  const itemsLower = items.map(i => i.trim().toLowerCase());
  const matched = foods.filter(f => itemsLower.includes(f.name.toLowerCase()));

  const avoid = matched.filter(f => f.acneRisk === 'high' || f.tags.includes('oily'));
  const good = matched.filter(f => f.acneRisk !== 'high' && !f.tags.includes('oily'));

  // Best combination: maximize protein + minimize acne risk
  const best = good.length ? good : matched.filter(f => f.acneRisk !== 'high');

  res.json({
    best: best.map(f => ({ name: f.name, reason: `Low acne risk, ${f.calories} cal, great tags: ${f.tags.join(', ')}` })),
    avoid: avoid.map(f => ({ name: f.name, reason: `High oil/acne risk (${f.acneRisk}), tags: ${f.tags.join(', ')}` }))
  });
});

const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
